package com.dicoding.myapplication.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.dicoding.myapplication.R
import com.dicoding.myapplication.data.response.ListEventsItem
import com.dicoding.myapplication.databinding.ActivityUserDetailBinding

@Suppress("DEPRECATION")
class UserDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding

    companion object {
        const val EXTRA_EVENT = "extra_event"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()


        val event = intent.getParcelableExtra<ListEventsItem>(EXTRA_EVENT)
        if (event != null) {
            setEventData(event)
        }

    }

    @SuppressLint("SetTextI18n")
    private fun setEventData(event: ListEventsItem) {
        binding.tvTitle.text = event.name
        binding.textOwnerName.text = getString(R.string.event_owner) + event.ownerName
        binding.textBeginTime.text = getString(R.string.event_time) + event.beginTime
        binding.textQuota.text = getString(R.string.event_quota) + (event.quota - event.registrants).toString()
        binding.textDescription.text = HtmlCompat.fromHtml(event.description.toString(),
            HtmlCompat.FROM_HTML_MODE_LEGACY
        )

        binding.buttonEventLink.text = getString(R.string.event_finish)

        Glide.with(this@UserDetailActivity)
            .load(event.imageLogo)
            .into(binding.imageLogo)

        binding.buttonEventLink.setOnClickListener {
            val eventUrl = event.link
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(eventUrl)
            }
            startActivity(intent)
        }
    }

}

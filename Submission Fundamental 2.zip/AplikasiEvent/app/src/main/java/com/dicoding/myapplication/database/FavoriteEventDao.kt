package com.dicoding.myapplication.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update


@Dao
interface FavoriteEventDao {

    @Query("SELECT * FROM favorite_event WHERE id = :id LIMIT 1")
    suspend fun getFavoriteEventById(id: String): FavoriteEvent?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(event: FavoriteEvent)

    @Delete
    suspend fun deleteFavorite(event: FavoriteEvent)

    @Update
    suspend fun updateFavorite(event: FavoriteEvent)

    @Query("SELECT * FROM favorite_event")
    suspend fun getAllFavorites(): List<FavoriteEvent>

}

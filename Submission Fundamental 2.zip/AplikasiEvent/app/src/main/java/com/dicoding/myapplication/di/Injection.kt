package com.dicoding.myapplication.di

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import com.dicoding.myapplication.database.EventRoomDatabase
import com.dicoding.myapplication.data.retrofit.ApiService
import com.dicoding.myapplication.repository.FavoriteRepository
import com.dicoding.myapplication.ui.FavoriteViewModel
import com.dicoding.myapplication.repository.FavoriteViewModelFactory
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object Injection {

    private const val BASE_URL = "https://event-api.dicoding.dev/"

    // Fungsi untuk menyediakan instance ApiService
    fun provideApiService(): ApiService {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(ApiService::class.java)
    }

    fun provideFavoriteViewModel(owner: ViewModelStoreOwner, context: Context): FavoriteViewModel {
        val database = EventRoomDatabase.getInstance(context)
        val favoriteRepository = FavoriteRepository.getInstance(database.favoriteEventDao())
        val factory = FavoriteViewModelFactory(context.applicationContext as Application, favoriteRepository)
        return ViewModelProvider(owner, factory).get(FavoriteViewModel::class.java)
    }
}

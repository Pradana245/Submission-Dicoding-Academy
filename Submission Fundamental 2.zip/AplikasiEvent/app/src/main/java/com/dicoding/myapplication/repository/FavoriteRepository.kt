package com.dicoding.myapplication.repository


import com.dicoding.myapplication.database.FavoriteEvent
import com.dicoding.myapplication.database.FavoriteEventDao

class FavoriteRepository private constructor(private val favoriteEventDao: FavoriteEventDao) {

    // Mengambil semua data favorit
    suspend fun getAllFavorites():List<FavoriteEvent> {
        return favoriteEventDao.getAllFavorites()
    }


    suspend fun getFavoriteById(id: String): FavoriteEvent? {
        return favoriteEventDao.getFavoriteEventById(id)
    }


    suspend fun insertFavorite(favoriteEvent: FavoriteEvent) {
        favoriteEventDao.insertFavorite(favoriteEvent)
    }


    suspend fun deleteFavorite(favoriteEvent: FavoriteEvent) {
        favoriteEventDao.deleteFavorite(favoriteEvent)
    }


    suspend fun updateFavorite(favoriteEvent: FavoriteEvent) {
        favoriteEventDao.updateFavorite(favoriteEvent)
    }

    companion object {
        @Volatile
        private var instance: FavoriteRepository? = null

        fun getInstance(dao: FavoriteEventDao): FavoriteRepository =
            instance ?: synchronized(this) {
                instance ?: FavoriteRepository(dao).also { instance = it }
            }
    }
}

package com.dicoding.myapplication.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.myapplication.data.response.ListEventsItem
import com.dicoding.myapplication.database.FavoriteEvent
import com.dicoding.myapplication.databinding.ItemUpcomingBinding

class EventAdapter : ListAdapter<ListEventsItem, EventAdapter.MyViewHolder>(DIFF_CALLBACK) {

    private var onItemClickCallback: OnItemClickCallback? = null

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemUpcomingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val event = getItem(position)
        holder.bind(event)
        holder.itemView.setOnClickListener {
            onItemClickCallback?.onItemClicked(event)
        }
    }

    // Fungsi untuk mengonversi FavoriteEvent ke ListEventsItem
    fun submitFavoriteList(favoriteEvents: List<FavoriteEvent>) {
        val eventList = favoriteEvents.map { favoriteEvent ->
            ListEventsItem(
                id = favoriteEvent.id,
                name = favoriteEvent.name,
                description = "",
                summary = "",
                mediaCover = favoriteEvent.mediacover ?: "",
                registrants = 0,
                imageLogo = "",
                link = "",
                ownerName = "",
                cityName = "",
                quota = 0,
                beginTime = "",
                endTime = "",
                category = ""
            )
        }
        submitList(eventList)
    }

    class MyViewHolder(private val binding: ItemUpcomingBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(event: ListEventsItem) {
            binding.tvUpcomingName.text = event.name

            Glide.with(binding.root.context)
                .load(event.mediaCover)
                .into(binding.eventImgPhoto)
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListEventsItem>() {
            override fun areItemsTheSame(oldItem: ListEventsItem, newItem: ListEventsItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: ListEventsItem, newItem: ListEventsItem): Boolean {
                return oldItem == newItem
            }
        }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: ListEventsItem)
    }
}

package com.dicoding.myapplication.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.myapplication.data.response.ListEventsItem
import com.dicoding.myapplication.databinding.FragmentFavoriteBinding
import com.dicoding.myapplication.di.Injection

class FavoriteFragment : Fragment() {
    private lateinit var viewModel: FavoriteViewModel
    private lateinit var eventAdapter: EventAdapter
    private lateinit var binding: FragmentFavoriteBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentFavoriteBinding.inflate(inflater, container, false)

        // Menggunakan Injection untuk mendapatkan ViewModel
        viewModel = Injection.provideFavoriteViewModel(this, requireContext())


        eventAdapter = EventAdapter()
        binding.rvFavorit.adapter = eventAdapter
        binding.rvFavorit.layoutManager = LinearLayoutManager(context)


        viewModel.isLoading.observe(viewLifecycleOwner, Observer { isLoading ->
            showLoading(isLoading)
        })

        // Observe daftar event favorit dari ViewModel
        viewModel.events.observe(viewLifecycleOwner) { favoriteEvents ->
            Log.d("FavoriteFragment", "Number of favorite events: ${favoriteEvents.size}")
            favoriteEvents?.let {
                eventAdapter.submitFavoriteList(it)  // Mengirim data favorit ke adapter
                binding.rvFavorit.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
            } ?: run {
                Log.d("FavoriteFragment", "favoriteEvents is null")
            }
        }

        viewModel.getAllFavorites()

        // Inisialisasi EventAdapter
        eventAdapter.setOnItemClickCallback(object : EventAdapter.OnItemClickCallback {
            override fun onItemClicked(event: ListEventsItem) {
                Log.d("FavoriteFragment", "Item clicked: $event")
                showSelectedEvent(event)
            }
        })

        return binding.root
    }

    private fun showLoading(loading: Boolean?) {
        binding.progressBar.visibility = if (loading == true) View.VISIBLE else View.GONE
    }

    private fun showSelectedEvent(data: ListEventsItem) {
        val intent = Intent(requireContext(), UserDetailActivity::class.java) // Gunakan requireContext() untuk fragment
        intent.putExtra(UserDetailActivity.EXTRA_EVENT, data)
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.getAllFavorites()
    }
}
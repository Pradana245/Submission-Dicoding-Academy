package com.dicoding.myapplication.ui

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.myapplication.data.response.Event
import com.dicoding.myapplication.database.FavoriteEvent
import com.dicoding.myapplication.repository.FavoriteRepository
import kotlinx.coroutines.launch

class FavoriteViewModel(application: Application, private val repository: FavoriteRepository) : ViewModel() {

    private val _currentEvent = MutableLiveData<Event>()
    val currentEvent: LiveData<Event> = _currentEvent

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    private val _events = MutableLiveData<List<FavoriteEvent>>()
    val events: LiveData<List<FavoriteEvent>> get() = _events


    private val _isFavorited = MutableLiveData<Boolean>()
    val isFavorited: LiveData<Boolean> get() = _isFavorited

    fun setCurrentEvent(event: Event) {
        _currentEvent.value = event
    }

    // Cek apakah event sudah ada di favorit berdasarkan ID
    fun getFavoriteById(id: String) = viewModelScope.launch {
        _isFavorited.value = repository.getFavoriteById(id) != null
    }

    fun getAllFavorites() = viewModelScope.launch {
        _isLoading.value = true
        _events.value = repository.getAllFavorites()
        _isLoading.value = false
    }

    // Menambahkan event ke favorit
    fun addFavorite(event: FavoriteEvent) = viewModelScope.launch {
        repository.insertFavorite(event)
        _isFavorited.value = true
    }

    fun updateFavorite(event: FavoriteEvent) = viewModelScope.launch {
        repository.updateFavorite(event)
        _isFavorited.value = true
    }

    fun deleteFavorite(event: FavoriteEvent) = viewModelScope.launch {
        repository.deleteFavorite(event)
        _isFavorited.value = false
    }
}

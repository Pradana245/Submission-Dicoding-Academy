package com.dicoding.myapplication.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.myapplication.R
import com.dicoding.myapplication.data.response.ListEventsItem

class UpcomingFragment : Fragment() {

    private lateinit var rvUpcoming: RecyclerView
    private lateinit var adapter: EventAdapter
    private lateinit var progressBar: ProgressBar
    private val viewModel: UpcomingViewModel by viewModels() // Use the ViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_upcoming, container, false)

        rvUpcoming = view.findViewById(R.id.rvUpcoming)
        progressBar = view.findViewById(R.id.progressBar)
        rvUpcoming.layoutManager = LinearLayoutManager(context)
        adapter = EventAdapter()
        rvUpcoming.adapter = adapter


        viewModel.events.observe(viewLifecycleOwner, Observer { eventList ->
            adapter.submitList(eventList)

        })
        viewModel.isLoading.observe(viewLifecycleOwner, Observer { isLoading ->
            showLoading(isLoading)
        })

        viewModel.fetchUpcomingEvents()

        // Set OnItemClickListener
        adapter.setOnItemClickCallback(object : EventAdapter.OnItemClickCallback {
            override fun onItemClicked(data: ListEventsItem) {
                showSelectedEvent(data)
            }
        })

        return view
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            progressBar.visibility = View.VISIBLE
            rvUpcoming.visibility = View.GONE
        } else {
            progressBar.visibility = View.GONE
            rvUpcoming.visibility = View.VISIBLE
        }
    }

    private fun showSelectedEvent(data: ListEventsItem) {
        val intent = Intent(context, UserDetailActivity::class.java)
        intent.putExtra(UserDetailActivity.EXTRA_EVENT, data)
        startActivity(intent)

    }

}

package com.dicoding.myapplication.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.dicoding.myapplication.R
import com.dicoding.myapplication.data.response.DetailEventResponse
import com.dicoding.myapplication.data.response.Event
import com.dicoding.myapplication.data.response.ListEventsItem
import com.dicoding.myapplication.database.FavoriteEvent
import com.dicoding.myapplication.databinding.ActivityUserDetailBinding
import com.dicoding.myapplication.di.Injection
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class UserDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding
    private lateinit var viewModel: FavoriteViewModel

    companion object {
        const val EXTRA_EVENT = "extra_event"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        // Menggunakan Injection untuk mendapatkan ViewModel
        viewModel = Injection.provideFavoriteViewModel(this, application)

        val event = intent.getParcelableExtra<ListEventsItem>(EXTRA_EVENT)
        event?.let {
            loadEventDetail(it.id.toString())  // Panggil API untuk mendapatkan detail event
            viewModel.getFavoriteById(it.id.toString())

            viewModel.isFavorited.observe(this) { isFavorited ->
                binding.fabFavorite.setImageResource(
                    if (isFavorited) R.drawable.ic_favorite_24
                    else R.drawable.baseline_favorite_border_24
                )
            }
        }

        // Tambah/hapus favorit ketika tombol favorit ditekan
        binding.fabFavorite.setOnClickListener {
            event?.let { eventItem ->
                val favoriteEvent = FavoriteEvent(
                    id = eventItem.id,
                    name = eventItem.name,
                    mediacover = eventItem.imageLogo
                )
                if (viewModel.isFavorited.value == true) {
                    viewModel.deleteFavorite(favoriteEvent)  // Menghapus favorit
                } else {
                    viewModel.addFavorite(favoriteEvent)  // Menambahkan favorit
                }
            }
        }
    }

    // Fungsi untuk memanggil API dan mendapatkan detail event
    private fun loadEventDetail(eventId: String) {
        val apiService = Injection.provideApiService()
        val call = apiService.getDetailEvent(eventId)
        call.enqueue(object : Callback<DetailEventResponse> {
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onResponse(
                call: Call<DetailEventResponse>,
                response: Response<DetailEventResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.event?.let { event ->
                        setEventData(event)
                        checkIfEventIsFinished(event)
                    }
                } else {
                    Log.e("UserDetailActivity", "Gagal memuat detail event.")
                }
            }

            override fun onFailure(call: Call<DetailEventResponse>, t: Throwable) {
                Log.e("UserDetailActivity", "Error: ${t.message}")
            }
        })
    }

    // Mengisi data event dari hasil API ke dalam UI
    @SuppressLint("SetTextI18n")
    private fun setEventData(event: Event) {
        binding.tvTitle.text = event.name
        binding.textOwnerName.text = getString(R.string.event_owner) + event.ownerName
        binding.textBeginTime.text = getString(R.string.event_time) + event.beginTime
        binding.textQuota.text = getString(R.string.event_quota) + (event.quota - event.registrants).toString()
        binding.textDescription.text = HtmlCompat.fromHtml(event.description.orEmpty(), HtmlCompat.FROM_HTML_MODE_LEGACY)

        Glide.with(this)
            .load(event.imageLogo)
            .into(binding.imageLogo)


        binding.buttonEventLink.setOnClickListener {
            val eventUrl = event.link
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(eventUrl))
            startActivity(intent)
        }
    }

    // Cek apakah event selesai dan update teks tombol
    @RequiresApi(Build.VERSION_CODES.O)
    private fun checkIfEventIsFinished(event: Event) {
        var isAvailable = event.registrants <= event.quota
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        val targetTime = LocalDateTime.parse(event.endTime, formatter)

        // Waktu sekarang
        val currentTime = LocalDateTime.now()
        if (currentTime.isAfter(targetTime)) {
            isAvailable = false
        }
        if (!isAvailable) {
            binding.buttonEventLink.text = getString(R.string.event_finish)
        } else {
            binding.buttonEventLink.text = getString(R.string.event_link)
        }
    }
}

package com.dicoding.storyapp.adapter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.databinding.CardviewStoryBinding
import com.dicoding.storyapp.view.detailstory.DetailStoryActivity
import java.text.SimpleDateFormat
import java.util.Locale

class StoryAdapter : RecyclerView.Adapter<StoryAdapter.MyViewHolder>() {

    private val storyList = mutableListOf<ListStoryItem>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding =
            CardviewStoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = storyList[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int = storyList.size

    fun setData(newList: List<ListStoryItem>) {
        val diffCallback = StoryDiffCallback(storyList, newList)
        val diffResult = DiffUtil.calculateDiff(diffCallback)
        storyList.clear()
        storyList.addAll(newList)
        diffResult.dispatchUpdatesTo(this)
    }

    class MyViewHolder(private val binding: CardviewStoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ListStoryItem) {
            val dateString = item.createdAt
            val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
            val date = inputFormat.parse(dateString)
            val outputFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
            val formattedDate = outputFormat.format(date)
            val optionsCompat: ActivityOptionsCompat =
                ActivityOptionsCompat.makeSceneTransitionAnimation(
                    itemView.context as Activity,
                    androidx.core.util.Pair(binding.imgItemPhoto, "image"),
                    androidx.core.util.Pair(binding.tvItemName, "name"),
                    androidx.core.util.Pair(binding.tvItemDescription, "description"),
                    androidx.core.util.Pair(binding.tvItemCreated, "date")
                )

            binding.apply {
                tvItemName.text = item.name
                tvItemCreated.text = formattedDate
                tvItemDescription.text = item.description

                Glide.with(itemView.context).load(item.photoUrl).into(imgItemPhoto)

                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailStoryActivity::class.java)
                    val bundle = Bundle()

                    bundle.putString("list_name", item.name)
                    bundle.putString("list_date", formattedDate)
                    bundle.putString("list_image", item.photoUrl)
                    bundle.putString("list_description", item.description)

                    intent.putExtras(bundle)
                    itemView.context.startActivity(intent, optionsCompat.toBundle())
                }
            }
        }
    }

    class StoryDiffCallback(
        private val oldList: List<ListStoryItem>, private val newList: List<ListStoryItem>
    ) : DiffUtil.Callback() {
        override fun getOldListSize(): Int = oldList.size

        override fun getNewListSize(): Int = newList.size

        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
            return oldList[oldItemPosition].id == newList[newItemPosition].id
        }

        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
            return oldList[oldItemPosition] == newList[newItemPosition]
        }
    }
}

package com.dicoding.storyapp.data.repository


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dicoding.storyapp.data.pref.UserPreference
import com.dicoding.storyapp.data.remote.ApiService
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.data.response.LoginResponse
import com.dicoding.storyapp.data.response.RegisterResponse
import kotlinx.coroutines.flow.first

class UserRepository(
    private val apiService: ApiService, private val userPreference: UserPreference
) {

    private val _stories = MutableLiveData<List<ListStoryItem>>()
    val stories: LiveData<List<ListStoryItem>> = _stories

    suspend fun registerUser(name: String, email: String, password: String): RegisterResponse {
        return try {
            val response = apiService.registerUser(name, email, password)
            response
        } catch (e: Exception) {
            RegisterResponse(error = true, message = e.message)
        }
    }

    suspend fun loginUser(email: String, password: String): LoginResponse {
        return try {
            val response = apiService.loginUser(email, password)
            response
        } catch (e: Exception) {
            LoginResponse(error = true, message = e.message)
        }
    }


    suspend fun fetchStories(): List<ListStoryItem> {
        return try {

            val token = userPreference.getUserToken.first()
            val response = apiService.getAllStory("Bearer $token")
            response.listStory
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getUserToken(): String? {
        return userPreference.getUserToken.first()
    }

    suspend fun clearUserData() {
        userPreference.clearUserToken()
        userPreference.clearUserLogin()
        userPreference.setStatusLogin(false)
    }


    suspend fun isUserLoggedIn(): Boolean {
        return userPreference.getStatusLogin.first()
    }

    suspend fun saveUserToken(token: String) {
        userPreference.saveUserToken(token)
    }

    suspend fun setStatusLogin(isLoggedIn: Boolean) {
        userPreference.setStatusLogin(isLoggedIn)
    }


    companion object {
        @Volatile
        private var instance: UserRepository? = null

        fun getInstance(apiService: ApiService, userPreference: UserPreference): UserRepository =
            instance ?: synchronized(this) {
                instance ?: UserRepository(apiService, userPreference).also { instance = it }
            }
    }
}
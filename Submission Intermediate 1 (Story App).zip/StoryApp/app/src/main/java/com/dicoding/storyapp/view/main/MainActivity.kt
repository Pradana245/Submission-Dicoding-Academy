package com.dicoding.storyapp.view.main

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.storyapp.R
import com.dicoding.storyapp.adapter.StoryAdapter
import com.dicoding.storyapp.data.pref.UserPreference
import com.dicoding.storyapp.data.remote.ApiConfig
import com.dicoding.storyapp.data.repository.UserRepository
import com.dicoding.storyapp.databinding.ActivityMainBinding
import com.dicoding.storyapp.view.MainViewModelFactory
import com.dicoding.storyapp.view.addstory.AddStoryActivity
import com.dicoding.storyapp.view.signin.SignInActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: StoryAdapter
    private val viewModel by viewModels<MainViewModel> {
        MainViewModelFactory(applicationContext)
    }

    companion object {
        const val SUCCESS_ADD_STORY = "success_add_story"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupAddStoryButton()
        handleAddStorySuccess()


        val userRepository =
            UserRepository.getInstance(ApiConfig.getApiService(), UserPreference.getInstance(this))


        observeUserToken(userRepository)
    }

    private fun setupRecyclerView() {
        adapter = StoryAdapter()
        binding.rvStory.layoutManager = LinearLayoutManager(this)
        binding.rvStory.setHasFixedSize(true)
        binding.rvStory.adapter = adapter
    }

    private fun setupAddStoryButton() {
        binding.btnAddStory.setOnClickListener {
            val intent = Intent(this@MainActivity, AddStoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun observeUserToken(userRepository: UserRepository) {
        lifecycleScope.launch {
            try {
                val token = userRepository.getUserToken()
                if (!token.isNullOrEmpty()) {
                    viewModel.getAllStory()
                } else {
                    Toast.makeText(this@MainActivity, "Token tidak ditemukan", Toast.LENGTH_SHORT)
                        .show()
                }

            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "Error fetching token: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        observeViewModel()
    }

    private fun observeViewModel() {

        viewModel.loading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }


        viewModel.listStory.observe(this) { stories ->
            if (!stories.isNullOrEmpty()) {
                adapter.setData(stories)
            } else {
                Toast.makeText(this, "Tidak ada Story", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleAddStorySuccess() {
        val success = intent.getBooleanExtra(SUCCESS_ADD_STORY, false)
        if (success) {
            Toast.makeText(this, "Story berhasil ditambahkan!", Toast.LENGTH_SHORT).show()
            observeUserToken(
                UserRepository.getInstance(
                    ApiConfig.getApiService(),
                    UserPreference.getInstance(this)
                )
            ) // Update stories after adding new one
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_item, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.btn_logout) {
            showLogoutDialog()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this).apply {
            setTitle("Keluar")
            setMessage("Apakah Anda yakin ingin keluar?")
            setPositiveButton("YA") { _, _ ->
                val userRepository = UserRepository.getInstance(
                    ApiConfig.getApiService(),
                    UserPreference.getInstance(this@MainActivity)
                )

                lifecycleScope.launch {

                    userRepository.clearUserData()
                    startActivity(Intent(this@MainActivity, SignInActivity::class.java))
                    finish()
                }
            }
            setNegativeButton("TIDAK") { dialog, _ -> dialog.dismiss() }
            create().show()
        }
    }
}

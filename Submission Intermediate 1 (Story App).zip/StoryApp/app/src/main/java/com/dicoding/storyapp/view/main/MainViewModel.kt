package com.dicoding.storyapp.view.main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.storyapp.data.repository.UserRepository
import com.dicoding.storyapp.data.response.ListStoryItem
import kotlinx.coroutines.launch

class MainViewModel(private val userRepository: UserRepository) : ViewModel() {

    private val _listStory = MutableLiveData<List<ListStoryItem>>()
    val listStory: LiveData<List<ListStoryItem>> = _listStory

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error


    fun getAllStory() {
        _loading.value = true
        viewModelScope.launch {
            try {

                val stories = userRepository.fetchStories()
                _loading.value = false
                _listStory.value = stories
            } catch (e: Exception) {
                _loading.value = false
                _error.value = "Gagal memuat cerita: ${e.message}"
                Log.e(TAG, "Error fetching stories: ${e.message}")
            }
        }
    }


    companion object {
        const val TAG = "MainViewModel"
    }
}
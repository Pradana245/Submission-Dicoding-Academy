package com.dicoding.storyapp.view.signin

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dicoding.storyapp.data.pref.UserPreference
import com.dicoding.storyapp.data.remote.ApiConfig
import com.dicoding.storyapp.data.repository.UserRepository
import com.dicoding.storyapp.databinding.ActivitySignInBinding
import com.dicoding.storyapp.view.SignInViewModelFactory
import com.dicoding.storyapp.view.main.MainActivity
import kotlinx.coroutines.launch

class SignInActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignInBinding
    private lateinit var userRepository: UserRepository
    private val signInViewModel: SignInViewModel by viewModels {
        SignInViewModelFactory(userRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userRepository =
            UserRepository.getInstance(ApiConfig.getApiService(), UserPreference.getInstance(this))


        lifecycleScope.launch {
            val isLoggedIn = userRepository.isUserLoggedIn()
            if (isLoggedIn) {
                navigateToMainActivity()
            }
        }

        showLoading(false)
        setLoginButtonEnabled()


        binding.emailEditText.addTextChangedListener(signInTextWatcher)
        binding.passwordEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s != null && s.length >= 8) setLoginButtonEnabled() else binding.loginButton.isEnabled =
                    false
            }

            override fun afterTextChanged(s: Editable?) {}
        })


        binding.loginButton.setOnClickListener {
            lifecycleScope.launch {
                val email = binding.emailEditText.text.toString()
                val password = binding.passwordEditText.text.toString()
                signInViewModel.login(email, password)
                showLoading(true)
            }
        }

        signInViewModel.loginResult.observe(this) { response ->
            showLoading(false)
            if (!response.error!!) {
                lifecycleScope.launch {
                    userRepository.saveUserToken(response.loginResult?.token ?: "")
                    userRepository.setStatusLogin(true)
                }
                navigateToMainActivity()
            } else {
                Toast.makeText(this@SignInActivity, "Login Failed!", Toast.LENGTH_LONG).show()
            }
        }

        signInViewModel.isLoading.observe(this) { isLoading ->
            showLoading(isLoading)
        }

        playAnimation()
    }

    private fun setLoginButtonEnabled() {
        val email = binding.emailEditText.text.toString()
        val password = binding.passwordEditText.text.toString()
        binding.loginButton.isEnabled = email.isNotEmpty() && password.isNotEmpty()
    }

    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if (state) View.VISIBLE else View.INVISIBLE
    }

    private fun navigateToMainActivity() {
        startActivity(Intent(this@SignInActivity, MainActivity::class.java))
        finishAffinity()
    }

    private fun playAnimation() {
        val fadeDuration = 500L
        ObjectAnimator.ofFloat(binding.imageView, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 5000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }

        val animations = listOf(
            ObjectAnimator.ofFloat(binding.titleTextView, View.ALPHA, 1f).setDuration(fadeDuration),
            ObjectAnimator.ofFloat(binding.messageTextView, View.ALPHA, 1f)
                .setDuration(fadeDuration),
            ObjectAnimator.ofFloat(binding.emailTextView, View.ALPHA, 1f).setDuration(fadeDuration),
            ObjectAnimator.ofFloat(binding.emailEditTextLayout, View.ALPHA, 1f)
                .setDuration(fadeDuration),
            ObjectAnimator.ofFloat(binding.passwordTextView, View.ALPHA, 1f)
                .setDuration(fadeDuration),
            ObjectAnimator.ofFloat(binding.passwordEditTextLayout, View.ALPHA, 1f)
                .setDuration(fadeDuration),
            ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(fadeDuration)
        )

        AnimatorSet().apply {
            playSequentially(animations)
            start()
        }
    }

    private val signInTextWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            setLoginButtonEnabled()
        }

        override fun afterTextChanged(s: Editable?) {}
    }
}
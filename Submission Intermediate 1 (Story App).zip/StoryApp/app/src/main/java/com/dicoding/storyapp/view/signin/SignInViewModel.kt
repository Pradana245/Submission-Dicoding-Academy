package com.dicoding.storyapp.view.signin

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.dicoding.storyapp.data.repository.UserRepository
import com.dicoding.storyapp.data.response.LoginResponse
import kotlinx.coroutines.launch

class SignInViewModel(application: Application, private val userRepository: UserRepository) :
    AndroidViewModel(application) {

    private val _loginResult = MutableLiveData<LoginResponse>()
    val loginResult: LiveData<LoginResponse> = _loginResult

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = userRepository.loginUser(email, password)
                _loginResult.value = response
            } catch (e: Exception) {
                _loginResult.value = LoginResponse(error = true, message = e.message)
            } finally {
                _isLoading.value = false
            }
        }
    }
}
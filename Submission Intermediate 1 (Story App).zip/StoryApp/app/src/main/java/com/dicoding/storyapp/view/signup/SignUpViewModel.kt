package com.dicoding.storyapp.view.signup

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.storyapp.data.pref.UserPreference
import com.dicoding.storyapp.data.remote.ApiConfig
import com.dicoding.storyapp.data.repository.UserRepository
import com.dicoding.storyapp.data.response.RegisterResponse
import kotlinx.coroutines.launch

class SignUpViewModel(application: Application) : AndroidViewModel(application) {
    private val userRepository: UserRepository = UserRepository.getInstance(
        ApiConfig.getApiService(), UserPreference.getInstance(application)
    )

    fun registerUser(
        name: String,
        email: String,
        password: String,
        onResult: (RegisterResponse) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val response = userRepository.registerUser(name, email, password)
                onResult(response)
            } catch (e: Exception) {
                e.printStackTrace()

            }
        }
    }
}
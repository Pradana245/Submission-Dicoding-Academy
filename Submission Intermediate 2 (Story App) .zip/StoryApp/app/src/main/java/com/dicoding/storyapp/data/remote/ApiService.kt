package com.dicoding.storyapp.data.remote

import com.dicoding.storyapp.data.response.AddStoryResponse
import com.dicoding.storyapp.data.response.AllStoryResponse
import com.dicoding.storyapp.data.response.DetailStoryResponse
import com.dicoding.storyapp.data.response.LoginResponse
import com.dicoding.storyapp.data.response.RegisterResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @POST("register")
    @FormUrlEncoded
    suspend fun registerUser(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): RegisterResponse


    @POST("login")
    @FormUrlEncoded
    suspend fun loginUser(
        @Field("email") email: String, @Field("password") password: String
    ): LoginResponse


    @GET("stories")
    suspend fun getAllStory(
        @Header("Authorization") token: String
    ): AllStoryResponse

    @GET("stories")
    suspend fun getStoryPaging(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20
    ): AllStoryResponse

    @Multipart
    @POST("stories")
    suspend fun uploadStory(
        @Header("Authorization") token: String,
        @Part file: MultipartBody.Part,
        @Part("description") description: RequestBody
    ): AddStoryResponse


    @GET("stories/:id")
    suspend fun getDetailStory(
        @Header("Authorization") token: String, @Path("id") id: String
    ): DetailStoryResponse

    @GET("stories")
    suspend fun getStoryLocation(
        @Header("Authorization") token: String,
        @Query("location") location: Int = 1
    ): AllStoryResponse

}
package com.dicoding.storyapp.data.repository


import androidx.lifecycle.LiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.storyapp.data.paging.StoryPaging
import com.dicoding.storyapp.data.pref.UserPreference
import com.dicoding.storyapp.data.remote.ApiService
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.data.response.LoginResponse
import com.dicoding.storyapp.data.response.RegisterResponse
import kotlinx.coroutines.flow.first

class UserRepository(
    private val apiService: ApiService, private val userPreference: UserPreference
) {

    suspend fun registerUser(name: String, email: String, password: String): RegisterResponse {
        return try {
            apiService.registerUser(name, email, password)
        } catch (e: Exception) {
            RegisterResponse(error = true, message = e.message)
        }
    }

    suspend fun loginUser(email: String, password: String): LoginResponse {
        return try {
            apiService.loginUser(email, password)
        } catch (e: Exception) {
            LoginResponse(error = true, message = e.message)
        }
    }

    suspend fun fetchStories(): List<ListStoryItem> {
        return try {

            val token = userPreference.getUserToken.first()
            val response = apiService.getAllStory("Bearer $token")
            response.listStory
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun clearUserData() {
        userPreference.clearUserToken()
        userPreference.clearUserLogin()
        userPreference.setStatusLogin(false)
    }

    suspend fun getUserToken(): String? {
        return userPreference.getUserToken.first()
    }

    suspend fun isUserLoggedIn(): Boolean = userPreference.getStatusLogin.first()

    suspend fun saveUserToken(token: String) {
        userPreference.saveUserToken(token)
    }

    suspend fun setStatusLogin(isLoggedIn: Boolean) {
        userPreference.setStatusLogin(isLoggedIn)
    }

    fun getStory(): LiveData<PagingData<ListStoryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 5,
                enablePlaceholders = false
            ),
            pagingSourceFactory = {
                StoryPaging(apiService, userPreference)
            }
        ).liveData
    }

    companion object {
        @Volatile
        private var instance: UserRepository? = null

        fun getInstance(apiService: ApiService, userPreference: UserPreference): UserRepository =
            instance ?: synchronized(this) {
                instance ?: UserRepository(apiService, userPreference).also { instance = it }
            }
    }
}

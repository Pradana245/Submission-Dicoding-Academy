package com.dicoding.storyapp.view.customview

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import com.dicoding.storyapp.R
import com.google.android.material.textfield.TextInputLayout

class PasswordEditText @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = android.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    init {
        hint = context.getString(R.string.hint_password)
        inputType =
            android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        setTextAppearance(android.R.style.TextAppearance_Material_Body1)
        setupPasswordValidation()
    }

    private fun setupPasswordValidation() {
        this.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s != null && s.length < 8) {
                    showError(context.getString(R.string.error_password_length)) // Error jika panjang password kurang dari 8
                } else {
                    clearError()
                }
            }

            override fun afterTextChanged(s: Editable?) {}

            private fun showError(errorMessage: String) {
                val parentLayout = parent.parent as? TextInputLayout
                parentLayout?.error = errorMessage
            }

            private fun clearError() {
                val parentLayout = parent.parent as? TextInputLayout
                parentLayout?.error = null
            }
        })
    }
}
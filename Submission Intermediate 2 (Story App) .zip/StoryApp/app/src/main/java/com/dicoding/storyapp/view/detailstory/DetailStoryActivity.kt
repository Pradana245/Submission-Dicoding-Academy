package com.dicoding.storyapp.view.detailstory

import android.os.Bundle
import android.transition.TransitionInflater
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.dicoding.storyapp.databinding.ActivityDetailStoryBinding

class DetailStoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailStoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)


        window.sharedElementEnterTransition =
            TransitionInflater.from(this).inflateTransition(android.R.transition.move)
        window.sharedElementReturnTransition =
            TransitionInflater.from(this).inflateTransition(android.R.transition.move)


        binding.tvDetailName.text = intent.getStringExtra("list_name")
        binding.tvDate.text = intent.getStringExtra("list_date")
        binding.tvDetailDescription.text = intent.getStringExtra("list_description")

        Glide.with(this).load(intent.getStringExtra("list_image")).into(binding.imgDetailPhoto)
    }
}
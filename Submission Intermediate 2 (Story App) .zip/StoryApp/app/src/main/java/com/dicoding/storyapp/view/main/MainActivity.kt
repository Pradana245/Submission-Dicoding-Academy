package com.dicoding.storyapp.view.main

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.storyapp.R
import com.dicoding.storyapp.adapter.StoryAdapter
import com.dicoding.storyapp.databinding.ActivityMainBinding
import com.dicoding.storyapp.view.MainViewModelFactory
import com.dicoding.storyapp.view.addstory.AddStoryActivity
import com.dicoding.storyapp.view.maps.MapsActivity
import com.dicoding.storyapp.view.signin.SignInActivity
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: StoryAdapter
    private val viewModel by viewModels<MainViewModel> {
        MainViewModelFactory(applicationContext)
    }

    companion object {
        const val SUCCESS_ADD_STORY = "success_add_story"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupAddStoryButton()
        handleAddStorySuccess()

        observeViewModel()
    }

    private fun setupRecyclerView() {
        val pagingAdapter = StoryAdapter()
        binding.rvStory.layoutManager = LinearLayoutManager(this)
        binding.rvStory.setHasFixedSize(true)
        binding.rvStory.adapter = pagingAdapter
        adapter = pagingAdapter
    }

    private fun setupAddStoryButton() {
        binding.btnAddStory.setOnClickListener {
            val intent = Intent(this@MainActivity, AddStoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun observeViewModel() {
        viewModel.getStories().observe(this) { pagingData ->
            adapter.submitData(lifecycle, pagingData)
        }
    }

    private fun handleAddStorySuccess() {
        val success = intent.getBooleanExtra(SUCCESS_ADD_STORY, false)
        if (success) {
            Toast.makeText(this, "Story berhasil ditambahkan!", Toast.LENGTH_SHORT).show()
            adapter.refresh()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_item, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.btn_logout -> {
                showLogoutDialog()
            }
            R.id.btn_maps -> {
                val intent = Intent(this, MapsActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this).apply {
            setTitle("Keluar")
            setMessage("Apakah Anda yakin ingin keluar?")
            setPositiveButton("YA") { _, _ ->
                lifecycleScope.launch {
                    viewModel.clearUserData()
                    startActivity(Intent(this@MainActivity, SignInActivity::class.java))
                    finish()
                }
            }
            setNegativeButton("TIDAK") { dialog, _ -> dialog.dismiss() }
            create().show()
        }
    }
}
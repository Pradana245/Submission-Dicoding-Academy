package com.dicoding.storyapp.view.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.storyapp.data.repository.UserRepository
import com.dicoding.storyapp.data.response.ListStoryItem


class MainViewModel(private val userRepository: UserRepository) : ViewModel() {

    fun getStories(): LiveData<PagingData<ListStoryItem>> {
        return userRepository.getStory().cachedIn(viewModelScope)
    }

    suspend fun clearUserData() {
        userRepository.clearUserData()
    }

    companion object {
        const val TAG = "MainViewModel"
    }
}

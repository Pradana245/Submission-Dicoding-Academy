package com.dicoding.storyapp.view.signup

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.dicoding.storyapp.databinding.ActivitySignUpBinding
import com.dicoding.storyapp.view.SignUpViewModelFactory
import com.dicoding.storyapp.view.signin.SignInActivity
import kotlinx.coroutines.launch

class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignUpBinding


    private val signUpViewModel: SignUpViewModel by lazy {
        ViewModelProvider(
            this, SignUpViewModelFactory(application)
        ).get(SignUpViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showLoading(false)
        setSignupButtonEnabled()

        binding.emailEditText.addTextChangedListener(signUpTextWatcher)
        binding.nameEditText.addTextChangedListener(signUpTextWatcher)
        binding.passwordEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                setSignupButtonEnabled()
            }

            override fun afterTextChanged(s: Editable) {}
        })

        binding.signupButton.setOnClickListener {
            lifecycleScope.launch {
                val name = binding.nameEditText.text.toString()
                val email = binding.emailEditText.text.toString()
                val password = binding.passwordEditText.text.toString()
                showLoading(true)
                signUpViewModel.registerUser(name, email, password) { response ->
                    showLoading(false)
                    if (!response.error!!) {
                        Toast.makeText(
                            this@SignUpActivity,
                            "Account created: ${response.message}",
                            Toast.LENGTH_LONG
                        ).show()
                        startActivity(Intent(this@SignUpActivity, SignInActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(
                            this@SignUpActivity,
                            "Registration failed: ${response.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }

        playAnimation()
    }

    private fun setSignupButtonEnabled() {
        val email = binding.emailEditText.text.toString()
        val password = binding.passwordEditText.text.toString()
        val name = binding.nameEditText.text.toString()
        binding.signupButton.isEnabled =
            email.isNotEmpty() && password.isNotEmpty() && name.isNotEmpty()
    }

    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if (state) View.VISIBLE else View.INVISIBLE
    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imageView, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 5000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }

        val animations = listOf(
            ObjectAnimator.ofFloat(binding.titleTextView, View.ALPHA, 1f).setDuration(500),
            ObjectAnimator.ofFloat(binding.nameTextView, View.ALPHA, 1f).setDuration(500),
            ObjectAnimator.ofFloat(binding.nameEditTextLayout, View.ALPHA, 1f).setDuration(500),
            ObjectAnimator.ofFloat(binding.emailTextView, View.ALPHA, 1f).setDuration(500),
            ObjectAnimator.ofFloat(binding.emailEditTextLayout, View.ALPHA, 1f).setDuration(500),
            ObjectAnimator.ofFloat(binding.passwordTextView, View.ALPHA, 1f).setDuration(500),
            ObjectAnimator.ofFloat(binding.passwordEditTextLayout, View.ALPHA, 1f).setDuration(500),
            ObjectAnimator.ofFloat(binding.signupButton, View.ALPHA, 1f).setDuration(500)
        )

        AnimatorSet().apply {
            playSequentially(animations)
            start()
        }
    }

    private val signUpTextWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            setSignupButtonEnabled()
        }

        override fun afterTextChanged(s: Editable?) {}
    }
}
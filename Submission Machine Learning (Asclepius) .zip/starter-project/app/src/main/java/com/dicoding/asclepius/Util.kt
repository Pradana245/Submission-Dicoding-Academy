package com.dicoding.asclepius

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

fun parseTimestamp(timestamp: Long): String {
    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    return dateFormat.format(Date(timestamp))
}

fun reformatTimestamp(
    timestampString: String,
    originalFormat: String = "yyyy-MM-dd'T'HH:mm:ss'Z'",
    targetFormat: String = "yyyy-MM-dd HH:mm:ss"
): String {
    return try {
        val sourceDateFormat = SimpleDateFormat(originalFormat, Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val destinationDateFormat = SimpleDateFormat(targetFormat, Locale.getDefault())
        val date = sourceDateFormat.parse(timestampString)
        destinationDateFormat.format(date ?: return "")
    } catch (e: Exception) {
        ""
    }
}

package com.dicoding.asclepius.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.asclepius.data.local.ClassificationResult
import com.dicoding.asclepius.databinding.ResultItemBinding
import com.dicoding.asclepius.parseTimestamp
import java.text.NumberFormat

class ResultAdapter(
    private val onDeleteClickListener: (ClassificationResult) -> Unit
) : ListAdapter<ClassificationResult, ResultAdapter.ResultViewHolder>(DIFF_CALLBACK) {

    inner class ResultViewHolder(private val itemBinding: ResultItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(dataItem: ClassificationResult) {

            Glide.with(itemView)
                .load(dataItem.imageUri)
                .into(itemBinding.ivImage)

            // Menampilkan label, skor, dan waktu pada tampilan item
            itemBinding.tvLabel.text = dataItem.label
            itemBinding.tvScore.text = NumberFormat.getPercentInstance().format(dataItem.score)
            itemBinding.tvTimestamp.text = parseTimestamp(dataItem.timestamp)

            // Mengatur aksi untuk tombol hapus
            itemBinding.btnDelete.setOnClickListener {
                onDeleteClickListener(dataItem)
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ClassificationResult>() {
            override fun areItemsTheSame(oldItem: ClassificationResult, newItem: ClassificationResult): Boolean {
                return oldItem.id == newItem.id
            }


            override fun areContentsTheSame(oldItem: ClassificationResult, newItem: ClassificationResult): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultViewHolder {

        val itemBinding = ResultItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ResultViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: ResultViewHolder, position: Int) {

        val dataItem = getItem(position)
        holder.bind(dataItem)

        holder.itemView.setOnClickListener {

        }
    }
}

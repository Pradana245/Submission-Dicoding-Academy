package com.dicoding.asclepius.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ClassificationResult::class], version = 1)
abstract class CancerDatabase : RoomDatabase() {
    abstract fun cancerDao(): CancerDao

    companion object {
        @Volatile
        private var INSTANCE: CancerDatabase? = null

        fun getDatabase(context: Context): CancerDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context,
                    CancerDatabase::class.java,
                    "cancer_detection_db"
                ).build()
            }
        }
    }
}
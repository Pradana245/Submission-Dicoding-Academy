package com.dicoding.asclepius.data.repository

import androidx.lifecycle.LiveData
import com.dicoding.asclepius.data.local.CancerDao
import com.dicoding.asclepius.data.local.ClassificationResult

class Repository(private val dao: CancerDao) {


    fun getAll(): LiveData<List<ClassificationResult>> {
        return dao.getAll()
    }

    suspend fun insert(classificationResult: ClassificationResult) {
        dao.insert(classificationResult)
    }

    suspend fun delete(classificationResult: ClassificationResult) {
        dao.delete(classificationResult)
    }

    companion object {
        @Volatile
        private var instance: Repository? = null

        fun getInstance(dao: CancerDao,): Repository =
            instance ?: synchronized(this) {
                instance ?: Repository(dao)
            }.also { instance = it }
    }
}
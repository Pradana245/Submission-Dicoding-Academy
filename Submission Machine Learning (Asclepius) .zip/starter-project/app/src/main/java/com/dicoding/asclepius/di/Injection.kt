package com.dicoding.asclepius.di

import android.content.Context
import com.dicoding.asclepius.data.local.CancerDatabase
import com.dicoding.asclepius.data.repository.Repository

object Injection {
    fun provideRepository(context: Context): Repository {
        val database = CancerDatabase.getDatabase(context)
        val dao = database.cancerDao()
        return Repository.getInstance(dao)
    }
}
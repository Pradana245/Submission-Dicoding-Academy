package com.dicoding.asclepius.helper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import com.dicoding.asclepius.R
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.common.ops.CastOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.task.core.BaseOptions
import org.tensorflow.lite.task.vision.classifier.Classifications
import org.tensorflow.lite.task.vision.classifier.ImageClassifier

class ImageClassifierHelper(
    private val context: Context,
    private val classifierListener: ClassifierListener?,
    private var threshold: Float = 0.1f,
    private var maxResults: Int = 2,
    private val modelName: String = "cancer_classification.tflite"
) {
    // Deklarasi variabel untuk menyimpan instance dari ImageClassifier
    private var imageClassifier: ImageClassifier? = null

    init {
        // Inisialisasi ImageClassifier ketika kelas diinstansiasi
        setupImageClassifier()
    }

    private fun setupImageClassifier() {
        // Mengatur opsi konfigurasi ImageClassifier
        val optionBuilder = ImageClassifier.ImageClassifierOptions.builder()
            .setScoreThreshold(threshold)
            .setMaxResults(maxResults)

        val baseOptionsBuilder = BaseOptions.builder()
            .setNumThreads(4)

        optionBuilder.setBaseOptions(baseOptionsBuilder.build())

        try {
            // Membuat ImageClassifier dari file model
            imageClassifier = ImageClassifier.createFromFileAndOptions(context, modelName, optionBuilder.build())
        } catch (e: IllegalStateException) {
            // Menangani kesalahan
            classifierListener?.onError(context.getString(R.string.classifier_failed))
            Log.e(TAG, e.message.toString())
        }
    }

    fun classifyStaticImage(imageUri: Uri) {
        if (imageClassifier == null) {
            setupImageClassifier()
        }

        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(224, 224, ResizeOp.ResizeMethod.NEAREST_NEIGHBOR))
            .add(CastOp(DataType.FLOAT32))
            .build()

        // Mengonversi gambar ke TensorImage yang siap diproses
        val tensorImage = imageProcessor.process(TensorImage.fromBitmap(uriToBitmap(imageUri)))

        // Menghitung waktu inferensi
        var inferenceTime = SystemClock.uptimeMillis()
        val results = imageClassifier?.classify(tensorImage)
        inferenceTime = SystemClock.uptimeMillis() - inferenceTime
        classifierListener?.onResults(results, inferenceTime)
    }

    private fun uriToBitmap(uri: Uri): Bitmap? {
        // Mengonversi URI gambar menjadi Bitmap
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            BitmapFactory.decodeStream(inputStream)
        } catch (e: Exception) {
            Log.e(TAG, e.message.toString())
            null
        }
    }

    interface ClassifierListener {
        fun onError(error: String)
        fun onResults(results: MutableList<Classifications>?, inferenceTime: Long)
    }

    companion object {
        private const val TAG = "ImageClassifierHelper"
    }
}

package com.dicoding.asclepius.view

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.asclepius.adapter.ResultAdapter
import com.dicoding.asclepius.data.local.ClassificationResult
import com.dicoding.asclepius.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private val viewModel: HistoryViewModel by viewModels {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Konfigurasi RecyclerView dan pengamatan data
        configureRecyclerView()
        observeResults()
        supportActionBar?.hide()
    }


    private fun observeResults() {
        viewModel.results.observe(this) { classificationResults ->
            updateResults(classificationResults)
        }
    }



    private fun updateResults(classificationResults: List<ClassificationResult>) {
        // Menyiapkan adapter dan menetapkan data untuk ditampilkan
        val resultsAdapter = ResultAdapter { item ->
            viewModel.deleteResult(item)
        }

        resultsAdapter.submitList(classificationResults)
        binding.rvHistory.adapter = resultsAdapter
    }

    private fun configureRecyclerView() {

        val linearLayoutManager = LinearLayoutManager(this)
        binding.rvHistory.layoutManager = linearLayoutManager
        val divider = DividerItemDecoration(this, linearLayoutManager.orientation)
        binding.rvHistory.addItemDecoration(divider)
    }
}

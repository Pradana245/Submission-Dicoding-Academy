package com.dicoding.asclepius.view

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.asclepius.data.local.ClassificationResult
import com.dicoding.asclepius.data.repository.Repository
import kotlinx.coroutines.launch

class HistoryViewModel(private val repository: Repository) : ViewModel() {
    private val _results = MutableLiveData<List<ClassificationResult>>()
    val results: LiveData<List<ClassificationResult>> = _results

    init {
        loadResults()
    }


    private fun loadResults() {
        viewModelScope.launch {
            repository.getAll().observeForever { results ->
                _results.postValue(results)
            }
        }
    }

    fun deleteResult(result: ClassificationResult) {
        viewModelScope.launch {

            repository.delete(result)
            loadResults()
        }
    }
}

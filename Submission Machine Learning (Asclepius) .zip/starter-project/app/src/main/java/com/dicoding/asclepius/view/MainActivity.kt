package com.dicoding.asclepius.view

import android.content.Intent
import android.net.Uri
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.Observer
import com.dicoding.asclepius.R
import com.dicoding.asclepius.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var mainBinding: ActivityMainBinding
    private val mainViewModel: MainViewModel by viewModels()

    // Launcher untuk memilih gambar dari galeri
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            mainViewModel.setSelectedImageUri(uri)
        } else {
            showToastMessage(getString(R.string.failed_to_pick_image))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBinding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        // Observasi perubahan pada URI gambar yang dipilih
        mainViewModel.selectedImageUri.observe(this, Observer { uri ->
            displayImage(uri)
        })

        setButtonState()

        // Mengatur listener untuk tombol galeri dan analisis
        mainBinding.galleryButton.setOnClickListener { openGallery() }
        mainBinding.analyzeButton.setOnClickListener { processImage() }
    }

    private fun setButtonState() {
        // Menonaktifkan tombol analisis jika tidak ada gambar yang dipilih
        mainBinding.analyzeButton.isEnabled = mainViewModel.selectedImageUri.value != null
    }

    private fun openGallery() {
        // Memulai pemilihan gambar dari galeri
        galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private fun displayImage(uri: Uri?) {
        uri?.let {
            mainBinding.previewImageView.setImageURI(it)
        }
        setButtonState()
    }

    private fun processImage() {
        // Memulai dengan URI gambar yang dipilih
        val resultIntent = Intent(this, ResultActivity::class.java)
        resultIntent.putExtra(ResultActivity.EXTRA_IMAGE_URI, mainViewModel.selectedImageUri.value.toString())
        startActivity(resultIntent)
    }

    private fun showToastMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_history -> {
                val historyIntent = Intent(this, HistoryActivity::class.java)
                startActivity(historyIntent)
            }
        }
        return true
    }

    companion object {
        private const val LOG_TAG = "MainActivity"
    }
}

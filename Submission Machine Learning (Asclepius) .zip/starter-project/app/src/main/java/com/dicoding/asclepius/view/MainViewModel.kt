package com.dicoding.asclepius.view

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    // LiveData untuk menyimpan URI gambar yang dipilih
    private val _selectedImageUri = MutableLiveData<Uri?>()
    val selectedImageUri: LiveData<Uri?> = _selectedImageUri

    // Fungsi untuk mengupdate URI gambar
    fun setSelectedImageUri(uri: Uri?) {
        _selectedImageUri.value = uri
    }
}

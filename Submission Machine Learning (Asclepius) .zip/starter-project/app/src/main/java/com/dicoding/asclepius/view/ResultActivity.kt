package com.dicoding.asclepius.view

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import com.dicoding.asclepius.R
import com.dicoding.asclepius.data.local.ClassificationResult
import com.dicoding.asclepius.databinding.ActivityResultBinding
import com.dicoding.asclepius.helper.ImageClassifierHelper
import org.tensorflow.lite.task.vision.classifier.Classifications
import java.text.NumberFormat

class ResultActivity : AppCompatActivity() {
    private lateinit var activityBinding: ActivityResultBinding
    private lateinit var classifierHelper: ImageClassifierHelper
    private val classifierViewModel: ResultViewModel by viewModels<ResultViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var classificationResult: ClassificationResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityBinding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(activityBinding.root)

        supportActionBar?.hide()


        handleIntentData()
    }

    private fun handleIntentData() {
        // Cek apakah Intent membawa URI gambar atau hasil klasifikasi
        intent.getStringExtra(EXTRA_IMAGE_URI)?.let {


            val imageUri = Uri.parse(it)
            activityBinding.resultImage.setImageURI(imageUri)
            initClassifier(imageUri)
            classifierHelper.classifyStaticImage(imageUri)

            // Simpan hasil klasifikasi saat tombol diklik
            activityBinding.btnAction.setOnClickListener {
                classificationResult?.let { classifierViewModel.insert(it) }
                finish()
            }
        } ?: run {

            classificationResult = getParcelableResult(intent)
            classificationResult?.let {
                updateUI(Uri.parse(it.imageUri), it.label, it.score)
            }
        }
    }

    private fun initClassifier(imageUri: Uri) {
        // Menginisialisasi classifier dengan listener untuk menangani hasil atau error
        classifierHelper = ImageClassifierHelper(
            context = this,
            classifierListener = object : ImageClassifierHelper.ClassifierListener {
                override fun onError(error: String) {
                    Toast.makeText(this@ResultActivity, error, Toast.LENGTH_SHORT).show()
                }

                override fun onResults(
                    results: MutableList<Classifications>?,
                    inferenceTime: Long
                ) {
                    runOnUiThread {
                        // Memproses hasil klasifikasi dan memperbarui tampilan
                        processClassificationResults(results, imageUri)
                    }
                }
            }
        )
    }

    private fun processClassificationResults(results: MutableList<Classifications>?, imageUri: Uri) {
        // Memilih kategori dengan skor tertinggi sebagai hasil klasifikasi
        results?.firstOrNull()?.categories?.maxByOrNull { it.score }?.let {
            updateUI(imageUri, it.label, it.score)
            classificationResult = ClassificationResult(
                timestamp = System.currentTimeMillis(),
                imageUri = imageUri.toString(),
                label = it.label,
                score = it.score
            )
        } ?: run {
            activityBinding.resultText.text = ""
        }
    }

    private fun updateUI(imageUri: Uri, label: String, score: Float) {
        // Memperbarui tampilan gambar dan teks berdasarkan hasil klasifikasi
        activityBinding.resultImage.setImageURI(imageUri)
        activityBinding.resultText.text =
            "${NumberFormat.getPercentInstance().format(score)} $label"


        if (label != "Cancer") {
            activityBinding.resultText.setTextColor(getColor(R.color.blue))
        }
    }

    private fun getParcelableResult(intent: Intent): ClassificationResult? {

        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT, ClassificationResult::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT)
        }
    }

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_RESULT = "extra_result"
    }
}

package com.dicoding.asclepius.view

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.asclepius.data.local.ClassificationResult
import com.dicoding.asclepius.data.repository.Repository
import kotlinx.coroutines.launch

class ResultViewModel(private val repository: Repository) : ViewModel() {

    fun insert(classificationResult: ClassificationResult) {
        viewModelScope.launch { repository.insert(classificationResult) }
    }

}